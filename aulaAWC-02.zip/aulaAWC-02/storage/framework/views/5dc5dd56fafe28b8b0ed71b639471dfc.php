<h1><?php echo e($post->title); ?></h1>
<p><?php echo e($post->content); ?><p><?php /**PATH C:\Users\pedro.afreires\aulaAWC-02\resources\views/posts/show.blade.php ENDPATH**/ ?>